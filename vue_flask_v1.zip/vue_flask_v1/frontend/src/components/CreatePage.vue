<template>
  <h1>Página de Crear</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>